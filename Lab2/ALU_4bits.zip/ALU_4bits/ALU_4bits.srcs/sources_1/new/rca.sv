`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2022/05/15 14:38:36
// Design Name: 
// Module Name: rca
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module rca(
input [3:0]A,
input [3:0]B,
input Cin,
output logic Cout,
output logic [3:0]S
    );
    logic [2:0]pass;
    fulladder f0(A[0],B[0],Cin,pass[0],S[0]);
    fulladder f1(A[1],B[1],pass[0],pass[1],S[1]);
    fulladder f2(A[2],B[2],pass[1],pass[2],S[2]);
    fulladder f3(A[3],B[3],pass[2],Cout,S[3]);
endmodule
