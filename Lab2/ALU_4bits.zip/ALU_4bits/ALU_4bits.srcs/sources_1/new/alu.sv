`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2022/05/15 16:20:52
// Design Name: 
// Module Name: alu
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module alu(
input [3 : 0] A,
input [3 : 0] B,
input [3 : 0] aluop,
output logic [7 : 0] alures,
output logic ZF,
output logic OF
    );
logic mark;
logic [3:0]a;
logic [3:0]b;
logic Cout;
logic [3:0]S;
rca adder(a,b,0,Cout,S);
always @(*) begin
ZF=0;
OF=0;
alures=0;
    case (aluop)
        4'b0000:alures[3:0]=A&B;
        4'b0001:alures[3:0]=A|B;
        4'b0010:alures[3:0]=A^B;
        4'b0011:alures[3:0]=~(A&B);
        4'b0100:alures[3:0]=~A;
        4'b0101:alures[3:0]=A<<B[2:0];
        4'b0110:alures[3:0]=A>>B[2:0];
        4'b0111:alures[3:0]=$signed(A)>>>B[2:0];
        4'b1000:alures=A*B;
        4'b1001:begin
            mark=0;
            if(A[3]==1)begin
                a=~A+1;
                mark=~mark;
            end
            else a=A;
            if(B[3]==1)begin
                b=~B+1;
                mark=~mark;
            end
            else b=B;
            alures=a*b;
            if(mark==1)alures=~alures+1;
        end
        4'b1010:begin
            a=A;
            b=B;
            alures={4'b0000,S};
            OF=Cout;
        end
        4'b1011:begin
            a=A;
            b=B;
            alures={4'b0000,S};
        end
        4'b1100:begin
            a=A;
            b=~B+1;
            alures={4'b0000,S};
            OF=Cout;
        end
        4'b1101:begin
            a=A;
            b=B;
            alures={4'b0000,S};
        end
        4'b1110:begin
            mark=A[3]^B[3];
            if(mark==0)alures=(A<B)?1:0;
            else alures=(A[3]==1)?1:0;
        end
        4'b1111:alures=(A<B)?1:0;
    endcase
    ZF=(alures==0);
end
endmodule