`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2022/05/16 20:17:48
// Design Name: 
// Module Name: ALU_4bits_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module ALU_4bits_tb();
logic[3:0] A,B,aluop;
logic[7:0] alures;
logic ZF,OF;
logic[21:0] stim[18:0];
int i;
logic ZFres,OFres;
logic [7:0]aluresres;
alu dut(A,B,aluop,alures,ZF,OF);
initial begin
$readmemb("test.txt",stim);
for(i=0;i<19;i=i+1) begin
{A,B,aluop,aluresres,ZFres,OFres}=stim[i];#10;
if(alures== aluresres&&ZF==ZFres&&OF==OFres)
$display($time,":pass");
else
$display($time, ":Error:A=%b ��B=%b,aluop=%b,alures=%b,ZF=%b,OF=%b,aluresres=%b,ZFres=%b,OFres=%b",A,B,aluop,alures,ZF,OF,aluresres,ZFres,OFres);
end
end
endmodule
